package com.example.appli_projet;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.myapplication.R;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import pageseleves.LoginStudent;
import pagesprof.LoginTeacher;
import pagesprof.Menu_Prof;

public class FirstPage extends AppCompatActivity {
    private TextView select_langue;
    private RelativeLayout relativelayouteleve;
    private RelativeLayout relativelayoutprof;
    private ConstraintLayout layout;
    private LinearLayout stripes;
    private ImageView power;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choix);

        this.select_langue=(TextView) findViewById(R.id.select_langue);
        this.relativelayouteleve=(RelativeLayout) findViewById(R.id.relativelayouteleve);
        this.relativelayoutprof=(RelativeLayout) findViewById(R.id.relativelayoutprof);


        layout = findViewById(R.id.layout);
        stripes= findViewById(R.id.stripes);

        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        Animation anim = AnimationUtils.loadAnimation(this,R.anim.stripe_anim);
        stripes.startAnimation(anim);

        Date now = new Date();

        DateFormat dateformatter = DateFormat.getDateInstance(DateFormat.SHORT);
        String formattedDate = dateformatter.format(now);

        DateFormat timeformatter = DateFormat.getTimeInstance(DateFormat.SHORT);
        String formattedTime = timeformatter.format(now);

        //power = findViewById(R.id.power);

//        power.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });

        select_langue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent select_langue = new Intent(getApplicationContext(), LanguageSelect.class);
                startActivity(select_langue);
                finish();
            }
        });

        relativelayouteleve.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent eleve = new Intent(getApplicationContext(), LoginStudent.class);
                startActivity(eleve);
                finish();
            }
        });

        relativelayoutprof.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent prof = new Intent(getApplicationContext(), LoginTeacher.class);
                startActivity(prof);
                finish();
            }
        });
    }
    public void onBackPressed(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(R.string.alertexit);
        alertDialogBuilder.setIcon(R.mipmap.ic_power);
        alertDialogBuilder.setMessage(R.string.exitApp);
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();


    }

    private void setAppLocale(String localeCode){
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            conf.setLocale(new Locale(localeCode.toLowerCase()));
        }
        else{
            conf.locale = new Locale(localeCode.toLowerCase());
        }
        res.updateConfiguration(conf,dm);
    }




}
