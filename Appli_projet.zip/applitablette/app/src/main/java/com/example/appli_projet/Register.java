package com.example.appli_projet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import pageseleves.LoginStudent;
import pagesprof.LoginTeacher;


public class Register extends AppCompatActivity {


    private RadioButton prof_button;
    private RadioButton eleve_button;
    private TextInputLayout til_nom,til_prenom,til_email, til_mdp1,til_mdp2;
    private EditText ed_nom, ed_prenom,ed_email, ed_mdp1, ed_mdp2;
    private CardView button;
    private ProgressBar loading;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        prof_button = (RadioButton) findViewById(R.id.prof_button);
        eleve_button = (RadioButton) findViewById(R.id.eleve_button);

        ed_nom = (EditText) findViewById(R.id.ed_nom);
        ed_prenom = (EditText) findViewById(R.id.ed_prenom);
        ed_email = (EditText) findViewById(R.id.ed_email);
        ed_mdp1 = (EditText) findViewById(R.id.ed_mdp1);
        ed_mdp2 = (EditText) findViewById(R.id.ed_mdp2);

        til_nom = (TextInputLayout) findViewById(R.id.til_nom);
        til_prenom = (TextInputLayout) findViewById(R.id.til_prenom);
        til_email = (TextInputLayout) findViewById(R.id.til_email);
        til_mdp1 = (TextInputLayout) findViewById(R.id.til_mdp1);
        til_mdp2 = (TextInputLayout) findViewById(R.id.til_mdp2);

        //loading = (ProgressBar) findViewById(R.id.loading);
        button = (CardView) findViewById(R.id.button);


        prof_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (prof_button.isChecked()) {
                    eleve_button.setChecked(false);
                } else {
                    prof_button.setChecked(true);
                }
            }
        });

        eleve_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eleve_button.isChecked()) {
                    prof_button.setChecked(false);
                } else {
                    eleve_button.setChecked(true);
                }
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkFields();
            }
        });
    }


    private void checkFields() {
        int error = 0;

        if(!isValidName(ed_nom.getText().toString())){
            if(ed_nom.length() < 3){
                til_nom.setError(getString(R.string.ToShortField));
                error++;
            }
            else if(ed_nom.length() > 24){
                til_nom.setError(getString(R.string.ToLongField));
                error++;
            }
            else {
                til_nom.setError(getString(R.string.InvalidSyntax));
                error++;
            }
        }
        else{
            til_nom.setErrorEnabled(false);
        }

        if(!isValidName(ed_prenom.getText().toString())){
            if(ed_prenom.length() < 3){
                til_prenom.setError(getString(R.string.ToShortField));
                error++;
            }
            else if(ed_nom.length() > 24){
                til_prenom.setError(getString(R.string.ToLongField));
                error++;
            }
            else {
                til_prenom.setError(getString(R.string.InvalidSyntax));
                error++;
            }
        }
        else{
            til_prenom.setErrorEnabled(false);
        }

        if (ed_email.length() == 0 || !isEmailValid(ed_email.getText().toString())) {

            til_email.setError(getString(R.string.InvalidEmail));
            error++;
        }
        else{
            til_email.setErrorEnabled(false);
        }

        if(ed_mdp1.length() == 0 && ed_mdp2.length() == 0){
            til_mdp2.setError(getString(R.string.EnterPassword));
            til_mdp1.setError(getString(R.string.EnterPassword));
            error++;
        }
        else if(ed_mdp1.length() == 0 && ed_mdp2.length() < 8){
            til_mdp2.setError("Password must contain at least 8 caracters");
            til_mdp1.setError(getString(R.string.EnterPassword));
            error++;
        }
        else if(ed_mdp1.length() < 8 && ed_mdp2.length() == 0){
            til_mdp1.setError("Password must contain at least 8 caracters");
            til_mdp2.setError(getString(R.string.EnterPassword));
            error++;
        }else if(ed_mdp1.length() < 8 && ed_mdp2.length() < 8){
            til_mdp2.setError("Password must contain at least 8 caracters");
            til_mdp1.setError("Password must contain at least 8 caracters");
            error++;
        }

        else if(ed_mdp1.length() == 0 && ed_mdp2.length() > 0){
            til_mdp2.setErrorEnabled(false);
            til_mdp1.setError(getString(R.string.EnterPassword));
            error++;
        }
        else if(ed_mdp1.length() > 0 && ed_mdp2.length() == 0){
            til_mdp1.setErrorEnabled(false);
            til_mdp2.setError(getString(R.string.EnterPassword));
            error++;
        }
        else if(ed_mdp1.length() > 0 && ed_mdp2.length() > 0 && ed_mdp1.getText().toString().equals(ed_mdp2.getText().toString())){
            til_mdp2.setErrorEnabled(false);
            til_mdp1.setErrorEnabled(false);
        }
        else if(!ed_mdp1.getText().toString().equals(ed_mdp2.getText().toString())){
            til_mdp1.setErrorEnabled(false);
            til_mdp2.setError(getString(R.string.NotSamePassword));
            error++;
        }
        else{
            til_mdp2.setErrorEnabled(false);
            til_mdp1.setErrorEnabled(false);
        }

        if(!prof_button.isChecked() && !eleve_button.isChecked()){
            Toast.makeText(this, R.string.SelectProfile, Toast.LENGTH_SHORT).show();
            error++;
        }


        if(error == 0){
            insertData();
        }
    }

    private void insertData() {
        final String nom = til_nom.getEditText().getText().toString().trim();
        final String prenom = til_prenom.getEditText().getText().toString().trim();
        final String email = til_email.getEditText().getText().toString().trim();
        final String password = til_mdp1.getEditText().getText().toString().trim();

        if(prof_button.isChecked()){
            StringRequest request = new StringRequest(Request.Method.POST, "http://92.148.72.130/register_prof.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try{
                        JSONObject jsonObject = new JSONObject(response);
                        String success = jsonObject.getString("success");
                        if(success.equals("1")){
                            Toast.makeText(Register.this, R.string.RegisterSuccess, Toast.LENGTH_SHORT).show();
                            Intent login = new Intent(getApplicationContext(), LoginTeacher.class);
                            startActivity(login);
                            finish();
                        }
                        else{
                            //Toast.makeText(Register.this, R.string.emailUsed, Toast.LENGTH_SHORT).show();
                            til_email.setError(getString(R.string.emailUsed));

                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(Register.this, "Register Error !" +e.toString(), Toast.LENGTH_LONG).show();

                    }

                }
                }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(Register.this, error.getMessage(),Toast.LENGTH_SHORT).show();

                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> params = new HashMap<String, String>();
                    params.put("nom",nom);
                    params.put("prenom",prenom);
                    params.put("email",email);
                    params.put("password",password);

                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(Register.this);
            requestQueue.add(request);

        }
        else{
            StringRequest request = new StringRequest(Request.Method.POST, "http://92.148.72.130/register_eleve.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try{
                        JSONObject jsonObject = new JSONObject(response);
                        String success = jsonObject.getString("success");
                        if(success.equals("1")){
                            Toast.makeText(Register.this, R.string.RegisterSuccess, Toast.LENGTH_SHORT).show();
                            Intent login = new Intent(getApplicationContext(), LoginStudent.class);
                            startActivity(login);
                            finish();
                        }
                        else{
                            //Toast.makeText(Register.this, R.string.emailUsed, Toast.LENGTH_SHORT).show();
                            til_email.setError(getString(R.string.emailUsed));
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(Register.this, "Register Error !" +e.toString(), Toast.LENGTH_SHORT).show();

                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(Register.this, error.getMessage(),Toast.LENGTH_SHORT).show();

                }
            }

            ){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> params = new HashMap<String, String>();
                    params.put("nom",nom);
                    params.put("prenom",prenom);
                    params.put("email",email);
                    params.put("password",password);

                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(Register.this);
            requestQueue.add(request);
        }

    }

    boolean isEmailValid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public static boolean isValidName(String name)   {
        String regex ="^[a-zA-ZàèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ -]{2,25}$";

        Pattern p = Pattern.compile(regex);
        if (name == null) {
            return false;
        }
        Matcher m = p.matcher(name);
        return m.matches();
    }

    public static boolean isValidFirstName(String name)   {

        String regex ="^[a-zA-ZàèìòùÀÈÌÒÙáéíóúýÁÉÍÓÚÝâêîôûÂÊÎÔÛãñõÃÑÕäëïöüÿÄËÏÖÜŸçÇßØøÅåÆæœ -]{2,25}$";
        Pattern p = Pattern.compile(regex);
        if (name == null) {
            return false;
        }
        Matcher m = p.matcher(name);
        return m.matches();
    }


}
