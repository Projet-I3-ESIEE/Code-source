package pageseleves;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import pagesprof.CreateQuiz;

public class AffichageQuiz extends AppCompatActivity {

    private TextView nbrQuestion, Question;
    private Button truetext, falsetext, textqcm1, textqcm2, textqcm3, textqcm4;
    private ProgressBar progress;
    private CheckBox check1, check2, check3, check4, truechecked, falsechecked;
    private TextInputLayout til_answer;
    private EditText ed_answer;
    private ImageView ardoise,ardoiseqcm1,ardoiseqcm2,ardoiseqcm3,ardoiseqcm4,ardoisetrue,ardoisefalse;
    int counter = 0;
    String score = "0";
    String cpt = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affichage_quiz);

        nbrQuestion = findViewById(R.id.numberQuestion);
        progress = findViewById(R.id.progress);
        Question = findViewById(R.id.question);
        check1 = findViewById(R.id.check1);
        check2 = findViewById(R.id.check2);
        check3 = findViewById(R.id.check3);
        check4 = findViewById(R.id.check4);
        textqcm1 = findViewById(R.id.textqcm1);
        textqcm2 = findViewById(R.id.textqcm2);
        textqcm3 = findViewById(R.id.textqcm3);
        textqcm4 = findViewById(R.id.textqcm4);
        til_answer = findViewById(R.id.til_answer);
        ed_answer = findViewById(R.id.ed_answer);
        truetext = findViewById(R.id.truetext);
        falsetext = findViewById(R.id.falsetext);
        truechecked = findViewById(R.id.truechecked);
        falsechecked = findViewById(R.id.falsechecked);
        ardoise = findViewById(R.id.ardoise);
        ardoiseqcm1 = findViewById(R.id.ardoiseqcm1);
        ardoiseqcm2 = findViewById(R.id.ardoiseqcm2);
        ardoiseqcm3 = findViewById(R.id.ardoiseqcm3);
        ardoiseqcm4 = findViewById(R.id.ardoiseqcm4);
        ardoisetrue = findViewById(R.id.ardoisetrue);
        ardoisefalse = findViewById(R.id.ardoisefalse);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");
        final String extraidQuiz = intent.getStringExtra("idQuiz");
        final String nomQuiz = intent.getStringExtra("nomQuiz");
        final String nbreal = intent.getStringExtra("nbreal");

        nbrQuestion.setText("Question 1");

        nbrQuestion(nomQuiz,cpt, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,nbreal);

        textqcm1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View v) {
                if (check1.isChecked()) {
                    check1.setChecked(false);
                    textqcm1.setTextColor(Color.parseColor("#FFFFFF"));
                } else {
                    check1.setChecked(true);
                    textqcm1.setTextColor(Color.parseColor("#BA535E"));
                }

            }
        });

        textqcm2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check2.isChecked()) {
                    check2.setChecked(false);
                    textqcm2.setTextColor(Color.parseColor("#FFFFFF"));
                } else {
                    check2.setChecked(true);
                    textqcm2.setTextColor(Color.parseColor("#BA535E"));
                }
            }
        });

        textqcm3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check3.isChecked()) {
                    check3.setChecked(false);
                    textqcm3.setTextColor(Color.parseColor("#FFFFFF"));
                } else {
                    check3.setChecked(true);
                    textqcm3.setTextColor(Color.parseColor("#BA535E"));
                }
            }
        });

        textqcm4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check4.isChecked()) {
                    check4.setChecked(false);
                    textqcm4.setTextColor(Color.parseColor("#FFFFFF"));
                } else {
                    check4.setChecked(true);
                    textqcm4.setTextColor(Color.parseColor("#BA535E"));
                }
            }
        });

        truetext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                truetext.setTextColor(Color.parseColor("#42D336"));
                falsetext.setTextColor(Color.parseColor("#FFFFFF"));
                truechecked.setChecked(true);
                falsechecked.setChecked(false);
            }
        });

        falsetext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                falsetext.setTextColor(Color.parseColor("#CB2722"));
                truetext.setTextColor(Color.parseColor("#FFFFFF"));
                truechecked.setChecked(false);
                falsechecked.setChecked(true);
            }
        });
    }

    private void prog(final String nomQuiz,final String nbrQuest, final String cpt, final String type, final String score, final String trueFalse, final String answer, final String qcmvrai1, final String qcmvrai2, final String qcmvrai3, final String qcmvrai4, final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName,final String question,final String nbreal) {

        final Timer t = new Timer();
        TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                counter++;
                progress.setProgress(counter);
                if (counter == 100) {

                    t.cancel();
                    int points = Integer.parseInt(score);
                    final String note;
                    int compteur = Integer.parseInt(cpt);
                    compteur++;
                    final String compte = Integer.toString(compteur);
                    int qcmrep1, qcmrep2, qcmrep3, qcmrep4;

                    if (type.equals("1")) {
                        if ((check1.isChecked() && qcmvrai1.equals("yes")) || (!check1.isChecked() && qcmvrai1.equals("no"))) {
                            qcmrep1 = 1;
                        } else {
                            qcmrep1 = 0;
                        }
                        if ((check2.isChecked() && qcmvrai2.equals("yes")) || (!check2.isChecked() && qcmvrai2.equals("no"))) {
                            qcmrep2 = 1;
                        } else {
                            qcmrep2 = 0;
                        }

                        if (textqcm3.getVisibility() == View.VISIBLE) {
                            if ((check3.isChecked() && qcmvrai3.equals("yes")) || (!check3.isChecked() && qcmvrai3.equals("no"))) {
                                qcmrep3 = 1;
                            } else {
                                qcmrep3 = 0;
                            }
                        } else {
                            qcmrep3 = 1;
                        }

                        if (textqcm3.getVisibility() == View.VISIBLE) {
                            if ((check4.isChecked() && qcmvrai4.equals("yes")) || (!check4.isChecked() && qcmvrai4.equals("no"))) {
                                qcmrep4 = 1;
                            } else {
                                qcmrep4 = 0;
                            }
                        } else {
                            qcmrep4 = 1;
                        }

                        if (qcmrep1 + qcmrep2 + qcmrep3 + qcmrep4 == 4) {
                            points++;
                            note = Integer.toString(points);
                        } else {
                            note = Integer.toString(points);
                        }

                    } else if (type.equals("2")) {
                        if (truechecked.isChecked() && trueFalse.equals("True")) {
                            points++;
                            note = Integer.toString(points);
                        } else if (falsechecked.isChecked() && trueFalse.equals("False")) {
                            points++;
                            note = Integer.toString(points);
                        } else {
                            note = Integer.toString(points);
                        }

                    } else {
                        String reponse = ed_answer.getText().toString().trim();
                        reponse = reponse.toLowerCase();
                        if (reponse.equals(answer)) {
                            points++;
                            note = Integer.toString(points);
                        } else {
                            note = Integer.toString(points);
                        }
                        final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
                        addAnswer(question, reponse, extraidQuiz, extraId , cpt);

                    }


                    if (nbrQuest.equals(cpt)) {
                        String mark = note+"/"+cpt;
                        ajoutNote(nomQuiz,cpt,note,extraId,extraidQuiz,nbreal);
                        leavequeue(extraidQuiz);
                        Intent act = new Intent(getApplicationContext(), FinQuiz.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        act.putExtra("score", note);
                        act.putExtra("cpt", cpt);
                        act.putExtra("idQuiz", extraidQuiz);
                        startActivity(act);
                        finish();
                    } else {

                        Quiz(nomQuiz,nbrQuest, compte, note, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,nbreal);
                    }

                }
            }
        };
        t.schedule(tt, 0, 310);//310
    }

    private void Quiz(final String nomQuiz,final String nbrQuest, final String cpt, final String score, final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName,final String nbreal) {

        StringRequest sr = new StringRequest(Request.Method.POST, "http://92.148.72.130/getQuestions.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);

                            String id = object.getString("id").trim();
                            String type = object.getString("type").trim();
                            String questions = object.getString("question").trim();
                            String qcm1 = object.getString("qcm1").trim();
                            String qcm2 = object.getString("qcm2").trim();
                            String qcm3 = object.getString("qcm3").trim();
                            String qcm4 = object.getString("qcm4").trim();
                            String qcmvrai1 = object.getString("qcmvrai1").trim();
                            String qcmvrai2 = object.getString("qcmvrai2").trim();
                            String qcmvrai3 = object.getString("qcmvrai3").trim();
                            String qcmvrai4 = object.getString("qcmvrai4").trim();
                            String TrueFalse = object.getString("TrueFalse").trim();
                            String answer = object.getString("answer").trim();
                            answer = answer.toLowerCase();

                            nbrQuestion.setText(id + "/" + nbrQuest);
                            Question.setText(questions);

                            textqcm1.setTextColor(Color.parseColor("#FFFFFF"));
                            textqcm2.setTextColor(Color.parseColor("#FFFFFF"));
                            textqcm3.setTextColor(Color.parseColor("#FFFFFF"));
                            textqcm4.setTextColor(Color.parseColor("#FFFFFF"));
                            check1.setChecked(false);
                            check2.setChecked(false);
                            check3.setChecked(false);
                            check4.setChecked(false);
                            truetext.setTextColor(Color.parseColor("#FFFFFF"));
                            falsetext.setTextColor(Color.parseColor("#FFFFFF"));
                            truechecked.setChecked(false);
                            falsechecked.setChecked(false);
                            ed_answer.setText("");

                            if (type.equals("1")) {
                                textqcm1.setText(qcm1);
                                textqcm2.setText(qcm2);
                                textqcm1.setVisibility(View.VISIBLE);
                                textqcm2.setVisibility(View.VISIBLE);
                                check1.setVisibility(View.INVISIBLE);
                                check2.setVisibility(View.INVISIBLE);
                                til_answer.setVisibility(View.INVISIBLE);
                                truetext.setVisibility(View.INVISIBLE);
                                falsetext.setVisibility(View.INVISIBLE);
                                ardoise.setVisibility(View.INVISIBLE);
                                ardoiseqcm1.setVisibility(View.VISIBLE);
                                ardoiseqcm2.setVisibility(View.VISIBLE);
                                ardoisetrue.setVisibility(View.INVISIBLE);
                                ardoisefalse.setVisibility(View.INVISIBLE);

                                if (!qcm3.equals("")) {
                                    textqcm3.setText(qcm3);
                                    textqcm3.setVisibility(View.VISIBLE);
                                    check3.setVisibility(View.INVISIBLE);
                                    ardoiseqcm3.setVisibility(View.VISIBLE);
                                } else {
                                    textqcm3.setVisibility(View.INVISIBLE);
                                    check3.setVisibility(View.INVISIBLE);
                                    ardoiseqcm3.setVisibility(View.INVISIBLE);
                                }

                                if (!qcm4.equals("")) {
                                    textqcm4.setText(qcm4);
                                    textqcm4.setVisibility(View.VISIBLE);
                                    check4.setVisibility(View.INVISIBLE);
                                    ardoiseqcm4.setVisibility(View.VISIBLE);
                                } else {
                                    textqcm4.setVisibility(View.INVISIBLE);
                                    check4.setVisibility(View.INVISIBLE);
                                    ardoiseqcm4.setVisibility(View.INVISIBLE);
                                }

                            } else if (type.equals("2")) {
                                textqcm1.setVisibility(View.INVISIBLE);
                                textqcm2.setVisibility(View.INVISIBLE);
                                textqcm3.setVisibility(View.INVISIBLE);
                                textqcm4.setVisibility(View.INVISIBLE);
                                check1.setVisibility(View.INVISIBLE);
                                check2.setVisibility(View.INVISIBLE);
                                check3.setVisibility(View.INVISIBLE);
                                check4.setVisibility(View.INVISIBLE);
                                til_answer.setVisibility(View.INVISIBLE);
                                truetext.setVisibility(View.VISIBLE);
                                falsetext.setVisibility(View.VISIBLE);
                                ardoise.setVisibility(View.INVISIBLE);
                                ardoiseqcm1.setVisibility(View.INVISIBLE);
                                ardoiseqcm2.setVisibility(View.INVISIBLE);
                                ardoiseqcm3.setVisibility(View.INVISIBLE);
                                ardoiseqcm4.setVisibility(View.INVISIBLE);
                                ardoisetrue.setVisibility(View.VISIBLE);
                                ardoisefalse.setVisibility(View.VISIBLE);


                            } else {
                                textqcm1.setVisibility(View.INVISIBLE);
                                textqcm2.setVisibility(View.INVISIBLE);
                                textqcm3.setVisibility(View.INVISIBLE);
                                textqcm4.setVisibility(View.INVISIBLE);
                                check1.setVisibility(View.INVISIBLE);
                                check2.setVisibility(View.INVISIBLE);
                                check3.setVisibility(View.INVISIBLE);
                                check4.setVisibility(View.INVISIBLE);
                                til_answer.setVisibility(View.VISIBLE);
                                truetext.setVisibility(View.INVISIBLE);
                                falsetext.setVisibility(View.INVISIBLE);
                                ardoise.setVisibility(View.VISIBLE);
                                ardoiseqcm1.setVisibility(View.INVISIBLE);
                                ardoiseqcm2.setVisibility(View.INVISIBLE);
                                ardoiseqcm3.setVisibility(View.INVISIBLE);
                                ardoiseqcm4.setVisibility(View.INVISIBLE);
                                ardoisetrue.setVisibility(View.INVISIBLE);
                                ardoisefalse.setVisibility(View.INVISIBLE);

                            }
                            counter = 0;
                            prog(nomQuiz,nbrQuest, cpt, type, score, TrueFalse, answer, qcmvrai1, qcmvrai2, qcmvrai3, qcmvrai4, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,questions,nbreal);

                        }

                    } else {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(AffichageQuiz.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AffichageQuiz.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", extraidQuiz);
                params.put("cpt", cpt);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(sr);

    }

    private void nbrQuestion(final String nomQuiz,final String cpt, final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName,final String nbreal) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/getnbrQuest.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String nbrQuest = object.getString("nbr").trim();
                            Quiz(nomQuiz,nbrQuest, cpt, score, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,nbreal);

                        }
                    } else {
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(AffichageQuiz.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AffichageQuiz.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", extraidQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void leavequeue(final String extraidQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/leavequeue.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AffichageQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",extraidQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private void ajoutNote(final String nomQuiz, final String nbr,final String note, final String extraId, final String extraidQuiz,final String nbreal) {
        Date now = new Date();

        DateFormat dateformatter = DateFormat.getDateInstance(DateFormat.SHORT);
        final String formattedDate = dateformatter.format(now);

        DateFormat timeformatter = DateFormat.getTimeInstance(DateFormat.SHORT);
        final String formattedTime = timeformatter.format(now);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/ajoutNote.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AffichageQuiz.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("ide", extraId);
                params.put("idQuiz", extraidQuiz);
                params.put("note", note);
                params.put("cpt", nbr);
                params.put("nomQuiz", nomQuiz);
                params.put("datenote", formattedDate);
                params.put("heure", formattedTime);
                params.put("nbr", nbreal);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void addAnswer(final String question, final String answer, final String idQuiz, final String id , final String numQuestion ){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/insertQuestion.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AffichageQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("ide",id);
                params.put("question",question);
                params.put("answer",answer);
                params.put("numQuestion",numQuestion);
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


    public void onBackPressed() {

    }
}
