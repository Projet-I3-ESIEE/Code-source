package pageseleves;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import pagesprof.Menu_Prof;
import pagesprof.MyQuiz;
import pagesprof.ProfileProf;

public class DetailsAct extends AppCompatActivity {

    private Button viewButton,claimButton;
    private TextView nameQuiz,note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        viewButton = findViewById(R.id.viewButton);
        claimButton = findViewById(R.id.claimButton);
        nameQuiz = findViewById(R.id.nameQuiz);
        note = findViewById(R.id.note);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");
        final String idQuiz = intent.getStringExtra("idQuiz");
        final String nomQuiz = intent.getStringExtra("nomQuiz");
        final String mark = intent.getStringExtra("note");

        nameQuiz.setText(nomQuiz+"\n"+idQuiz);
        note.setText(mark+" / 20");

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myActivities);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myActivities:
                        Intent act3 = new Intent(getApplicationContext(), ActivitiesEleve.class);
                        act3.putExtra("nom", extraName);
                        act3.putExtra("email", extraEmail);
                        act3.putExtra("prenom", extraFirstName);
                        act3.putExtra("id", extraId);
                        startActivity(act3);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myProfile:
                        Intent act2 = new Intent(getApplicationContext(), ProfileProf.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                }
                return false;
            }

        });

        viewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), ViewAnswer.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                act.putExtra("idQuiz", idQuiz);
                startActivity(act);
                finish();
            }
        });

        claimButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), Reclamation.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                act.putExtra("idQuiz", idQuiz);
                startActivity(act);
                finish();

            }
        });
    }

    public void onBackPressed(){

    }
}
