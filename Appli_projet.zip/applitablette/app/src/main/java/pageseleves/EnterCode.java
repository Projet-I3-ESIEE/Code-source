package pageseleves;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EnterCode extends AppCompatActivity {

    private EditText ed_code;
    private Button enterQuiz;
    private TextInputLayout til_code;
    private String url = "http://81.49.43.234/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_code);

        ed_code = findViewById(R.id.ed_code);
        til_code = findViewById(R.id.til_code);
        enterQuiz = (Button)findViewById(R.id.enterQuiz);


        Intent intent = getIntent();
        final String extraName=intent.getStringExtra("nom");
        final String extraFirstName=intent.getStringExtra("prenom");
        final String extraEmail=intent.getStringExtra("email");
        final String extraId=intent.getStringExtra("id");

        enterQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed_code.length() == 0){
                    Toast.makeText(EnterCode.this, "Please enter a code", Toast.LENGTH_SHORT).show();
                }else{
                    checkCode(extraEmail,extraFirstName,extraId,extraName);
                }
            }
        });

    }


    private void checkCode(final String extraEmail, final String extraFirstName, final String extraId, final String extraName) {
        final String idQuiz = ed_code.getText().toString().trim();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"enterCode.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String nomQuiz = object.getString("nomQuiz").trim();

                            ed_code.setText("");
                            til_code.setErrorEnabled(false);

                            Intent act = new Intent(getApplicationContext(), Quiz.class);
                            act.putExtra("nom", extraName);
                            act.putExtra("prenom", extraFirstName);
                            act.putExtra("email", extraEmail);
                            act.putExtra("id", extraId);
                            act.putExtra("nomQuiz", nomQuiz);
                            act.putExtra("idQuiz", idQuiz);
                            startActivity(act);
                            finish();
                        }
                    }
                    else{
                        til_code.setError("The code is not correct");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(EnterCode.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }



            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EnterCode.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
