package pageseleves;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;

import pagesprof.ViewQuiz;

public class FinQuiz extends AppCompatActivity {

    private Button viewstat, backmenu;
    private TextView scoreIs, comment;
    private String url = "http://81.49.43.234/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fin_quiz);

        viewstat = findViewById(R.id.viewstat);
        backmenu = findViewById(R.id.backmenu);
        comment = findViewById(R.id.commentary);
        scoreIs = findViewById(R.id.scoreIs);

        Intent intent = getIntent();
        final String nom = intent.getStringExtra("nom");
        final String email = intent.getStringExtra("email");
        final String prenom = intent.getStringExtra("prenom");
        final String id = intent.getStringExtra("id");
        final String score = intent.getStringExtra("score");
        final String cpt = intent.getStringExtra("cpt");
        final String idQuiz = intent.getStringExtra("idQuiz");

        int pts = Integer.parseInt(score);
        int total = Integer.parseInt(cpt);
        double ratio = (float)pts / (float)total;
        double mark = ratio*20;

        NumberFormat format = NumberFormat.getNumberInstance();
        format.setMinimumFractionDigits(1); //nb de chiffres apres la virgule
        String s = format.format(mark);

        String rate = Double.toString(mark);
        if (ratio == 1) {
            comment.setText(R.string.perfect);
        } else if (ratio == 0) {
            comment.setText(R.string.zero);
        } else if (ratio >= 0.75 && ratio < 1) {
            comment.setText(R.string.verygood);
        } else if (ratio >= 0.5 && ratio < 0.75) {
            comment.setText(R.string.quitegood);
        } else if (ratio >= 0.25 && ratio < 0.5) {
            comment.setText(R.string.somedifficulties);
        } else if (ratio >= 0.01 && ratio < 0.25) {
            comment.setText(R.string.workmore);
        }

        scoreIs.setText(s+"/20");

        backmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), Menu_eleve.class);
                act.putExtra("nom", nom);
                act.putExtra("prenom", prenom);
                act.putExtra("email", email);
                act.putExtra("id", id);
                startActivity(act);
                finish();
            }
        });

        viewstat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), ViewAnswer.class);
                act.putExtra("nom", nom);
                act.putExtra("email", email);
                act.putExtra("prenom", prenom);
                act.putExtra("id", id);
                act.putExtra("idQuiz", idQuiz);
                startActivity(act);
                finish();

            }
        });

        editStat(id,rate);

    }

    private void editStat(final String id,final String note){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"editStat.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(FinQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("ide",id);
                params.put("note",note);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void onBackPressed(){

    }

}
