package pageseleves;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.appli_projet.FirstPage;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ProfileEleve extends AppCompatActivity {

    private TextView nom,edit;
    private Button logout;
    private String url = "http://81.49.43.234/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_eleve);

        nom = findViewById(R.id.infoname);
        logout = findViewById(R.id.logout);
        edit = findViewById(R.id.editprofile);

        final Intent intent = getIntent();
        final String extraName=intent.getStringExtra("nom");
        final String extraFirstName=intent.getStringExtra("prenom");
        final String extraEmail=intent.getStringExtra("email");
        final String extraId=intent.getStringExtra("id");

        BottomNavigationView bottomNavigationView = findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myProfile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.myActivities:
                        Intent act = new Intent(getApplicationContext(), ActivitiesEleve.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                    case R.id.myProfile:
                        break;
                    case R.id.home:
                        Intent act2 = new Intent(getApplicationContext(), Menu_eleve.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                }
                return false;
            }
        });

        nom.setText(extraFirstName+" "+extraName+"\n"+extraEmail);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), FirstPage.class);
                startActivity(act);
                finish();
            }
        });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act2 = new Intent(getApplicationContext(), editprofileEleve.class);
                act2.putExtra("nom", extraName);
                act2.putExtra("email", extraEmail);
                act2.putExtra("prenom", extraFirstName);
                act2.putExtra("id", extraId);
                startActivity(act2);
                finish();
            }
        });
    }

    public void onBackPressed(){

    }

}
