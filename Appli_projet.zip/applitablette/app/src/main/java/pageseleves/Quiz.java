package pageseleves;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Quiz extends AppCompatActivity {

    private TextView nomQuiz;
    private ConstraintLayout layout;
    private LinearLayout stripes;
    private Button exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        nomQuiz = findViewById(R.id.nomQuiz);

        Intent intent = getIntent();
        final String extraName=intent.getStringExtra("nom");
        final String extraFirstName=intent.getStringExtra("prenom");
        final String extraEmail=intent.getStringExtra("email");
        final String extraId=intent.getStringExtra("id");
        final String extraNomQuiz = intent.getStringExtra("nomQuiz");
        final String extraidQuiz = intent.getStringExtra("idQuiz");

        layout = findViewById(R.id.layout);
        stripes= findViewById(R.id.stripes);
        exit= findViewById(R.id.btnexit);

        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        Animation anim = AnimationUtils.loadAnimation(this,R.anim.stripe_anim);
        stripes.startAnimation(anim);
        
        nbrReal(extraNomQuiz,extraEmail,extraFirstName,extraId,extraidQuiz,extraName,extraNomQuiz);

        nomQuiz.setText(extraNomQuiz);
        joinqueue(extraidQuiz);

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                leavequeue(extraidQuiz);

                Intent act = new Intent(getApplicationContext(), Menu_eleve.class);
                act.putExtra("nom",extraName);
                act.putExtra("email",extraEmail);
                act.putExtra("prenom",extraFirstName);
                act.putExtra("id",extraId);
                startActivity(act);
                finish();

            }
        });

    }

    private void leavequeue(final String extraidQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/leavequeue.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Quiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",extraidQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void joinqueue(final String extraidQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/joinqueue.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Quiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",extraidQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void checkStatut(final String nomQuiz,final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName, final String extraNomQuiz,final String nbrReal) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/waitingRoom.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String statut = object.getString("statut").trim();

                            if(statut.equals("off")){
                                checkStatut(nomQuiz,extraEmail,extraFirstName,extraId,extraidQuiz,extraName,extraNomQuiz,nbrReal);
                            }
                            else{
                                Intent act = new Intent(getApplicationContext(), AffichageQuiz.class);
                                act.putExtra("nom", extraName);
                                act.putExtra("prenom", extraFirstName);
                                act.putExtra("email", extraEmail);
                                act.putExtra("id", extraId);
                                act.putExtra("idQuiz", extraidQuiz);
                                act.putExtra("nomQuiz", nomQuiz);
                                act.putExtra("nbreal", nbrReal);
                                startActivity(act);
                                finish();

                            }

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Quiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Quiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",extraidQuiz);
                for(int j=0;j<1000000000;j++);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void nbrReal(final String nomQuiz,final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName, final String extraNomQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/nbrReal.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String nbrReal = object.getString("nbr").trim();

                            int compteur = Integer.parseInt(nbrReal);
                            compteur++;
                            final String compte = Integer.toString(compteur);

                            checkStatut(extraNomQuiz,extraEmail,extraFirstName,extraId,extraidQuiz,extraName,extraNomQuiz,compte);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Quiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Quiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",extraidQuiz);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void onBackPressed(){

    }

}
