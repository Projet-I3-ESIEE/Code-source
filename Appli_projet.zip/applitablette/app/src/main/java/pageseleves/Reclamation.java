package pageseleves;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import pagesprof.EditQuiz;
import pagesprof.InfoResult;
import pagesprof.QuizResults;

public class Reclamation extends AppCompatActivity {

    public LinearLayout layout;
    private TextView noQuiz;
    private ProgressBar loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reclamation);

        layout = findViewById(R.id.myQuizLayout);
        noQuiz = findViewById(R.id.noQuiz);
        loading = findViewById(R.id.loadingBar);

        loading.setVisibility(View.VISIBLE);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");
        final String idQuiz = intent.getStringExtra("idQuiz");

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myActivities);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        Intent act = new Intent(getApplicationContext(), Menu_eleve.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myActivities:
                        Intent act3 = new Intent(getApplicationContext(), ActivitiesEleve.class);
                        act3.putExtra("nom", extraName);
                        act3.putExtra("email", extraEmail);
                        act3.putExtra("prenom", extraFirstName);
                        act3.putExtra("id", extraId);
                        startActivity(act3);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myProfile:
                        Intent act2 = new Intent(getApplicationContext(), ProfileEleve.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                }
                return false;
            }
        });

        getnbrQuest(idQuiz, extraId, extraName, extraFirstName, extraEmail);

    }

    private void getnbrQuest(final String idQuiz, final String extraId, final String extraName, final String extraFirstName, final String extraEmail) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/getNbrQuest.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String nbrQuiz = object.getString("nbr").trim();
                            String numMax = object.getString("num").trim();
                            String cpt = "0";

                            if (!nbrQuiz.equals("0")) {
                                listQuiz(idQuiz, extraId, numMax, nbrQuiz, cpt, extraEmail, extraFirstName, extraName);

                            } else {
                                loading.setVisibility(View.INVISIBLE);
                                noQuiz.setVisibility(View.VISIBLE);
                            }

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Reclamation.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Reclamation.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("ide", extraId);
                params.put("idQuiz", idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void listQuiz(final String idQuiz, final String extraId, final String num, final String nbrQuiz, final String cpt, final String extraEmail, final String extraFirstName, final String extraName) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/listAnswers.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            final String numQuestion = object.getString("numQuestion").trim();
                            final String question = object.getString("question").trim();
                            final String answer = object.getString("answer").trim();
                            final String realans = object.getString("realans").trim();
                            String num = object.getString("id").trim();

                            int nbr = Integer.parseInt(num);
                            nbr--;
                            num = Integer.toString(nbr);

                            int compteur = Integer.parseInt(cpt);
                            compteur++;
                            final String compte = Integer.toString(compteur);

                            if (compteur == 1) {
                                Button button = new Button(Reclamation.this);
                                button.setText(question + "\n \n" + getString(R.string.youranswer) + answer + "\n" + getString(R.string.correctans) + realans);
                                button.setId(compteur);
                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                params.gravity = Gravity.CENTER_HORIZONTAL;
                                params.setMargins(5, 100, 5, 50);
                                button.setTextColor(getResources().getColor(R.color.white));
                                button.setBackgroundColor(getResources().getColor(R.color.add));
                                button.setMinLines(3);
                                button.setMaxLines(5);
                                button.setAlpha((float) 0.7);
                                button.setTextSize(18);
                                layout.addView(button, params);


                            } else if (compte.equals(nbrQuiz)) {

                                Button button = new Button(Reclamation.this);
                                button.setText(question + "\n \n" + getString(R.string.youranswer) + answer + "\n" + getString(R.string.correctans) + realans);
                                button.setId(compteur);
                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                params.gravity = Gravity.CENTER_HORIZONTAL;
                                params.setMargins(5, 60, 5, 200);
                                button.setTextColor(getResources().getColor(R.color.white));
                                button.setBackgroundColor(getResources().getColor(R.color.add));
                                button.setMinLines(3);
                                button.setMaxLines(5);
                                button.setAlpha((float) 0.7);
                                button.setTextSize(18);
                                layout.addView(button, params);
                            } else {
                                Button button = new Button(Reclamation.this);
                                button.setText(question + "\n \n" + getString(R.string.youranswer) + answer + "\n" + getString(R.string.correctans) + realans);
                                button.setId(compteur);
                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                params.gravity = Gravity.CENTER_HORIZONTAL;
                                params.setMargins(5, 60, 5, 50);
                                button.setTextColor(getResources().getColor(R.color.white));
                                button.setBackgroundColor(getResources().getColor(R.color.add));
                                button.setAlpha((float) 0.7);
                                button.setMinLines(3);
                                button.setMaxLines(5);
                                button.setTextSize(18);
                                layout.addView(button, params);
                            }

                            final Button button1;
                            button1 = findViewById(compteur);
                            button1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //String idQuiz = txt.substring(tailleNomQuiz);
                                    //String nomQuiz = txt.substring(0,tailleNomQuiz-2);
//
                                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Reclamation.this);
                                    alertDialogBuilder.setTitle(R.string.claimtitle);
                                    //alertDialogBuilder.setIcon(R.mipmap.redcross);
                                    alertDialogBuilder.setMessage(R.string.surewanttoclaim);
                                    alertDialogBuilder.setCancelable(false);
                                    alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            makeclaim(idQuiz, numQuestion, question, answer, realans, extraId);
                                            Intent act = new Intent(getApplicationContext(), Reclamation.class);
                                            act.putExtra("nom", extraName);
                                            act.putExtra("email", extraEmail);
                                            act.putExtra("prenom", extraFirstName);
                                            act.putExtra("id", extraId);
                                            act.putExtra("idQuiz", idQuiz);
                                            startActivity(act);
                                            finish();
                                        }
                                    });
                                    alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                        }
                                    });
                                    AlertDialog alertDialog = alertDialogBuilder.create();
                                    alertDialog.show();


                                }
                            });

                            if (compte.equals(nbrQuiz)) {
                                loading.setVisibility(View.INVISIBLE);
                            } else {
                                listQuiz(idQuiz, extraId, num, nbrQuiz, compte, extraEmail, extraFirstName, extraName);
                            }

                        }
                    } else {
                        int nbr = Integer.parseInt(num);
                        nbr--;
                        String nmbr = Integer.toString(nbr);
                        listQuiz(idQuiz, extraId, nmbr, nbrQuiz, cpt, extraEmail, extraFirstName, extraName);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Reclamation.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Reclamation.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("ide", extraId);
                params.put("num", num);
                params.put("idQuiz", idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void makeclaim(final String idQuiz, final String numQuestion, final String question, final String answer, final String realans, final String ide) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/makeClaim.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Reclamation.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("numQuestion", numQuestion);
                params.put("idQuiz", idQuiz);
                params.put("question", question);
                params.put("answer", answer);
                params.put("realanswer", realans);
                params.put("ide", ide);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void onBackPressed() {

    }
}
