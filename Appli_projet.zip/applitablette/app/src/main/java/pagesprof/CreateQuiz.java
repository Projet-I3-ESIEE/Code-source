package pagesprof;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class CreateQuiz extends AppCompatActivity {

    private RadioButton qcm,trueFalse,openQuestion,buttonTrue,buttonFalse;
    private TextInputLayout til_question,til_qcm1,til_qcm2,til_qcm3,til_qcm4,til_answer;
    private EditText ed_question,ed_answer,ed_qcm1,ed_qcm2,ed_qcm3,ed_qcm4;
    private ImageView addanswer, removeanswer;
    private CardView add,cancel,finish;
    private TextView questNum,trueOrFalse,infoQCM;
    private CheckBox check1,check2,check3,check4;
    private LinearLayout radioGroup,radioGroup2;
    private String url = "http://81.49.43.234/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_quiz);

        Intent intent = getIntent();
        final String extraName=intent.getStringExtra("nom");
        final String extraFirstName=intent.getStringExtra("prenom");
        final String extraEmail=intent.getStringExtra("email");
        final String extraId=intent.getStringExtra("id");
        final String idQuiz = intent.getStringExtra("idQuiz");

        final String idProf= extraId.toString().trim();

        trueOrFalse = findViewById(R.id.trueOrFalse);
        questNum = findViewById(R.id.question);
        infoQCM = findViewById(R.id.infoQCM);
        questNum.setText("Question 1");
        check1 = findViewById(R.id.check1);
        check2 = findViewById(R.id.check2);
        check3 = findViewById(R.id.check3);
        check4 = findViewById(R.id.check4);
        qcm = (RadioButton) findViewById(R.id.qcm);
        trueFalse = (RadioButton) findViewById(R.id.trueFalse);
        buttonFalse = (RadioButton) findViewById(R.id.buttonFalse);
        buttonTrue = (RadioButton) findViewById(R.id.buttonTrue);
        openQuestion = findViewById(R.id.write);
        ed_question = (EditText) findViewById(R.id.ed_question);
        ed_answer = (EditText) findViewById(R.id.ed_answer);
        ed_qcm1 = (EditText) findViewById(R.id.ed_qcm1);
        ed_qcm2 = (EditText) findViewById(R.id.ed_qcm2);
        ed_qcm3 = (EditText) findViewById(R.id.ed_qcm3);
        ed_qcm4 = (EditText) findViewById(R.id.ed_qcm4);
        til_question = (TextInputLayout) findViewById(R.id.til_question);
        til_answer = (TextInputLayout) findViewById(R.id.til_answer);
        til_qcm1 = (TextInputLayout) findViewById(R.id.til_qcm1);
        til_qcm2 = (TextInputLayout) findViewById(R.id.til_qcm2);
        til_qcm3 = (TextInputLayout) findViewById(R.id.til_qcm3);
        til_qcm4 = (TextInputLayout) findViewById(R.id.til_qcm4);
        add = (CardView) findViewById(R.id.add);
        finish = (CardView) findViewById(R.id.finish);
        cancel = (CardView) findViewById(R.id.cancel);
        addanswer = (ImageView) findViewById(R.id.addanswerqcm);
        removeanswer = (ImageView) findViewById(R.id.removeanswerqcm);


        qcm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                trueFalse.setChecked(false);
                openQuestion.setChecked(false);
                til_answer.setVisibility(View.INVISIBLE);
                til_qcm1.setVisibility(View.VISIBLE);
                til_qcm2.setVisibility(View.VISIBLE);
                til_qcm3.setVisibility(View.INVISIBLE);
                til_qcm4.setVisibility(View.INVISIBLE);
                infoQCM.setVisibility(View.VISIBLE);
                addanswer.setVisibility(View.VISIBLE);
                removeanswer.setVisibility(View.VISIBLE);
                check1.setVisibility(View.VISIBLE);
                check2.setVisibility(View.VISIBLE);
                check3.setVisibility(View.INVISIBLE);
                check4.setVisibility(View.INVISIBLE);
                trueOrFalse.setVisibility(View.INVISIBLE);
                buttonFalse.setVisibility(View.INVISIBLE);
                buttonTrue.setVisibility(View.INVISIBLE);
                buttonTrue.setChecked(false);
                buttonFalse.setChecked(false);

                addanswer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(til_qcm3.getVisibility() == View.INVISIBLE && til_qcm4.getVisibility() == View.INVISIBLE){
                            til_qcm3.setVisibility(View.VISIBLE);
                            check3.setVisibility(View.VISIBLE);
                        }
                        else if(til_qcm3.getVisibility() == View.VISIBLE && til_qcm4.getVisibility() == View.INVISIBLE){
                            til_qcm4.setVisibility(View.VISIBLE);
                            check4.setVisibility(View.VISIBLE);
                        }
                    }
                });

                removeanswer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(til_qcm3.getVisibility() == View.VISIBLE && til_qcm4.getVisibility() == View.VISIBLE){
                            til_qcm4.setVisibility(View.INVISIBLE);
                            ed_qcm4.setText("");
                            check4.setChecked(false);
                            check4.setVisibility(View.INVISIBLE);

                        }
                        else if(til_qcm3.getVisibility() == View.VISIBLE && til_qcm4.getVisibility() == View.INVISIBLE){
                            til_qcm3.setVisibility(View.INVISIBLE);
                            ed_qcm3.setText("");
                            check3.setChecked(false);
                            check3.setVisibility(View.INVISIBLE);
                        }
                    }
                });

            }
        });

        trueFalse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                qcm.setChecked(false);
                openQuestion.setChecked(false);
                addanswer.setVisibility(View.INVISIBLE);
                removeanswer.setVisibility(View.INVISIBLE);
                til_answer.setVisibility(View.INVISIBLE);
                til_qcm1.setVisibility(View.INVISIBLE);
                til_qcm2.setVisibility(View.INVISIBLE);
                til_qcm3.setVisibility(View.INVISIBLE);
                til_qcm4.setVisibility(View.INVISIBLE);
                trueOrFalse.setVisibility(View.VISIBLE);
                buttonFalse.setVisibility(View.VISIBLE);
                buttonTrue.setVisibility(View.VISIBLE);
                infoQCM.setVisibility(View.INVISIBLE);
                check1.setVisibility(View.INVISIBLE);
                check2.setVisibility(View.INVISIBLE);
                check3.setVisibility(View.INVISIBLE);
                check4.setVisibility(View.INVISIBLE);
                check1.setChecked(false);
                check2.setChecked(false);
                check3.setChecked(false);
                check4.setChecked(false);

                buttonFalse.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        buttonTrue.setChecked(false);
                    }
                });

                buttonTrue.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        buttonFalse.setChecked(false);
                    }
                });
            }
        });

        openQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                qcm.setChecked(false);
                trueFalse.setChecked(false);
                addanswer.setVisibility(View.INVISIBLE);
                removeanswer.setVisibility(View.INVISIBLE);
                til_answer.setVisibility(View.VISIBLE);
                til_qcm1.setVisibility(View.INVISIBLE);
                til_qcm2.setVisibility(View.INVISIBLE);
                til_qcm3.setVisibility(View.INVISIBLE);
                til_qcm4.setVisibility(View.INVISIBLE);
                trueOrFalse.setVisibility(View.INVISIBLE);
                buttonFalse.setVisibility(View.INVISIBLE);
                buttonTrue.setVisibility(View.INVISIBLE);
                buttonTrue.setChecked(false);
                buttonFalse.setChecked(false);
                infoQCM.setVisibility(View.INVISIBLE);
                check1.setVisibility(View.INVISIBLE);
                check2.setVisibility(View.INVISIBLE);
                check3.setVisibility(View.INVISIBLE);
                check4.setVisibility(View.INVISIBLE);
                check1.setChecked(false);
                check2.setChecked(false);
                check3.setChecked(false);
                check4.setChecked(false);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(CreateQuiz.this);
                alertDialogBuilder.setTitle(R.string.alertcanceltitle);
                alertDialogBuilder.setIcon(R.mipmap.redcross);
                alertDialogBuilder.setMessage(R.string.cancelquiz);
                alertDialogBuilder.setCancelable(false);
                alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dropTable(idQuiz);

                        Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                        act.putExtra("nom",extraName);
                        act.putExtra("email",extraEmail);
                        act.putExtra("prenom",extraFirstName);
                        act.putExtra("id",extraId);
                        startActivity(act);
                        finish();
                    }
                });
                alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int error = checkFields();
                if(error == 0){
                    String question = ed_question.getText().toString().trim();
                    String answer,qcm1,qcm2,qcm3,qcm4,qcmvrai1,qcmvrai2,qcmvrai3,qcmvrai4,trueorFalse;
                    String type;
                    if(qcm.isChecked()){
                        type="1";
                        answer = "";
                        qcm1=ed_qcm1.getText().toString().trim();
                        qcm2=ed_qcm2.getText().toString().trim();
                        qcm3=ed_qcm3.getText().toString().trim();
                        qcm4=ed_qcm4.getText().toString().trim();
                        trueorFalse="";
                        if(check1.isChecked()){
                            qcmvrai1="yes";
                        }
                        else{
                            qcmvrai1="no";
                        }
                        if(check2.isChecked()){
                            qcmvrai2="yes";
                        }
                        else{
                            qcmvrai2="no";
                        }

                        if(til_qcm3.getVisibility() == View.VISIBLE){
                            if(check3.isChecked()){
                                qcmvrai3="yes";
                            }
                            else{
                                qcmvrai3="no";
                            }
                        }
                        else{
                            qcmvrai3="no";
                            qcm3="";
                        }


                        if(til_qcm4.getVisibility() == View.VISIBLE){
                            if(check4.isChecked()){
                                qcmvrai4="yes";
                            }
                            else{
                                qcmvrai4="no";
                            }
                        }
                        else{
                            qcmvrai4="no";
                            qcm4="";
                        }

                    }
                    else if(trueFalse.isChecked()){
                        type="2";
                        answer = "";
                        qcm1="";
                        qcm2="";
                        qcm3="";
                        qcm4="";
                        qcmvrai1="";
                        qcmvrai2="";
                        qcmvrai3="";
                        qcmvrai4="";
                        if(buttonTrue.isChecked()){
                            trueorFalse="True";
                        }else{
                            trueorFalse="False";
                        }

                    }else{
                        type="3";
                        answer = ed_answer.getText().toString().trim();
                        qcm1="";
                        qcm2="";
                        qcm3="";
                        qcm4="";
                        qcmvrai1="";
                        qcmvrai2="";
                        qcmvrai3="";
                        qcmvrai4="";
                        trueorFalse="";
                    }

                    addToBDD(question,answer,type,idQuiz,idProf,trueorFalse,qcm1,qcm2,qcm3,qcm4,qcmvrai1,qcmvrai2,qcmvrai3,qcmvrai4);
                }
            }
        });

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String quest = questNum.getText().toString().trim();
                if(quest.equals("Question 1")){
                    Toast.makeText(CreateQuiz.this, R.string.atleastonequestion, Toast.LENGTH_SHORT).show();

                }else {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(CreateQuiz.this);
                    alertDialogBuilder.setTitle(R.string.alertfinishtitle);
                    alertDialogBuilder.setIcon(R.drawable.createquiz);
                    alertDialogBuilder.setMessage(R.string.quizfinished);
                    alertDialogBuilder.setCancelable(false);
                    alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent act = new Intent(getApplicationContext(), FinishQuiz.class);
                            act.putExtra("nom", extraName);
                            act.putExtra("email", extraEmail);
                            act.putExtra("prenom", extraFirstName);
                            act.putExtra("id", extraId);
                            act.putExtra("idQuiz", idQuiz);
                            startActivity(act);
                            finish();
                        }
                    });
                    alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });
    }


    private void dropTable(final String idQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url+"cancelQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(CreateQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void addToBDD(final String question, final String answer, final String type, final String idQuiz, final String idProf,final String trueorFalse,final String qcm1, final String qcm2, final String qcm3, final String qcm4, final String qcmvrai1, final String qcmvrai2, final String qcmvrai3,  final String qcmvrai4 ){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url+"addQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);

                            String idQ=object.getString("idQ").trim();
                            int idquest = Integer.parseInt(idQ);
                            int nbr=idquest+1;

                            //Toast.makeText(CreateQuiz.this, idQ, Toast.LENGTH_SHORT).show();
                            ed_question.setText("");
                            ed_answer.setText("");
                            ed_qcm1.setText("");
                            ed_qcm2.setText("");
                            ed_qcm3.setText("");
                            ed_qcm4.setText("");
                            buttonFalse.setChecked(false);
                            buttonTrue.setChecked(false);
                            qcm.setChecked(false);
                            trueFalse.setChecked(false);
                            openQuestion.setChecked(false);
                            check1.setChecked(false);
                            check2.setChecked(false);
                            check3.setChecked(false);
                            check4.setChecked(false);
                            til_answer.setVisibility(View.INVISIBLE);
                            til_qcm1.setVisibility(View.INVISIBLE);
                            til_qcm2.setVisibility(View.INVISIBLE);
                            til_qcm3.setVisibility(View.INVISIBLE);
                            til_qcm4.setVisibility(View.INVISIBLE);
                            trueOrFalse.setVisibility(View.INVISIBLE);
                            buttonFalse.setVisibility(View.INVISIBLE);
                            buttonTrue.setVisibility(View.INVISIBLE);
                            infoQCM.setVisibility(View.INVISIBLE);
                            check1.setVisibility(View.INVISIBLE);
                            check2.setVisibility(View.INVISIBLE);
                            check3.setVisibility(View.INVISIBLE);
                            check4.setVisibility(View.INVISIBLE);
                            addanswer.setVisibility(View.INVISIBLE);
                            removeanswer.setVisibility(View.INVISIBLE);

                            questNum.setText("Question "+nbr);
                        }
                    }
                    else{
                        Toast.makeText(CreateQuiz.this, "not ok", Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(CreateQuiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(CreateQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idProf",idProf);
                params.put("question",question);
                params.put("answer",answer);
                params.put("trueFalse",trueorFalse);
                params.put("qcm1",qcm1);
                params.put("qcm2",qcm2);
                params.put("qcm3",qcm3);
                params.put("qcm4",qcm4);
                params.put("qcmvrai1",qcmvrai1);
                params.put("qcmvrai2",qcmvrai2);
                params.put("qcmvrai3",qcmvrai3);
                params.put("qcmvrai4",qcmvrai4);
                params.put("type",type);
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void onBackPressed(){
    }


    private int checkFields() {
        int error = 0;
        if(!qcm.isChecked() && !trueFalse.isChecked() && !openQuestion.isChecked()){
            //qcm.setTextColor(Color.parseColor("#DC143C"));
            //trueFalse.setTextColor(Color.parseColor("#DC143C"));
            //openQuestion.setTextColor(Color.parseColor("#DC143C"));
            Toast.makeText(this, R.string.select_type, Toast.LENGTH_SHORT).show();
            error++;
        }
        if(ed_question.length() == 0){
            error++;
            til_question.setError(getString(R.string.enter_question));
        }
        else if(ed_question.length() >= 255){
            error++;
            til_question.setError(getString(R.string.questiontooLong));
        }
        else{
            til_question.setErrorEnabled(false);
        }


        if(qcm.isChecked()){
            if(ed_qcm1.length() == 0){
                error++;
                til_qcm1.setError(getString(R.string.enter_question));
            }else if(ed_qcm1.length() >= 60){
                error++;
                til_qcm1.setError(getString(R.string.answertooLong));
            }
            else{
                til_qcm1.setErrorEnabled(false);
            }
            if(ed_qcm2.length() == 0){
                error++;
                til_qcm2.setError(getString(R.string.enter_question));
            }else if(ed_qcm2.length() >= 60){
                error++;
                til_qcm2.setError(getString(R.string.answertooLong));
            }
            else{
                til_qcm2.setErrorEnabled(false);
            }

            if(til_qcm3.getVisibility() == View.VISIBLE){
                if(ed_qcm3.length() == 0){
                    error++;
                    til_qcm3.setError(getString(R.string.enter_question));
                }else if(ed_qcm3.length() >= 60){
                    error++;
                    til_qcm3.setError(getString(R.string.answertooLong));
                }
                else{
                    til_qcm3.setErrorEnabled(false);
                }

            }else{
                til_qcm3.setErrorEnabled(false);
            }

            if(til_qcm4.getVisibility() == View.VISIBLE) {
                if (ed_qcm4.length() == 0) {
                    error++;
                    til_qcm4.setError(getString(R.string.enter_question));
                } else if (ed_qcm4.length() >= 60) {
                    error++;
                    til_qcm4.setError(getString(R.string.answertooLong));
                } else {
                    til_qcm4.setErrorEnabled(false);

                }
            }
            else{
                til_qcm4.setErrorEnabled(false);
            }
            if(!check1.isChecked() && !check2.isChecked() && !check3.isChecked() && !check4.isChecked()){
                error++;
                infoQCM.setTextColor(Color.parseColor("#FF0000"));
            }
            else if(check1.isChecked() && check2.isChecked() && check3.isChecked() && check4.isChecked()){
                error++;
                infoQCM.setTextColor(Color.parseColor("#FF0000"));
            }
            else if(check1.isChecked() && check2.isChecked() && til_qcm3.getVisibility()==View.INVISIBLE){
                error++;
                infoQCM.setTextColor(Color.parseColor("#FF0000"));
            }
            else if(check1.isChecked() && check2.isChecked() && check3.isChecked() && til_qcm4.getVisibility()==View.INVISIBLE){
                error++;
                infoQCM.setTextColor(Color.parseColor("#FF0000"));
            }
            else{
                infoQCM.setTextColor(Color.parseColor("#000000"));
            }


        }else if(trueFalse.isChecked()){
            if(!buttonTrue.isChecked() && !buttonFalse.isChecked()){
                error++;
                trueOrFalse.setTextColor(Color.parseColor("#FF0000"));
            }
            else{
                trueOrFalse.setTextColor(Color.parseColor("#000000"));
            }


        }else if(openQuestion.isChecked()){
            if(ed_answer.length() == 0){
                error++;
                til_answer.setError(getString(R.string.enter_answer));
            }
            else if(ed_answer.length() >= 60){
                error++;
                til_answer.setError(getString(R.string.answertooLong));
            }
            else{
                til_answer.setErrorEnabled(false);
            }
        }

        return error;
    }
}
