package pagesprof;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class EditQuiz extends AppCompatActivity {

    private Button DeleteButton,LaunchButton;
    private TextView nameQuiz,nbrco;
    private String url = "http://81.49.43.234/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_quiz);

        LaunchButton = findViewById(R.id.LaunchButton);
        DeleteButton = findViewById(R.id.DeleteButton);
        nameQuiz = findViewById(R.id.nameQuiz);
        nbrco = findViewById(R.id.nbrco);


        Intent intent = getIntent();
        final String idQuiz=intent.getStringExtra("idQuiz");
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");
        final String nomQuiz = intent.getStringExtra("nomQuiz");
        final String enattente = intent.getStringExtra("enattente");

        nameQuiz.setText(nomQuiz+"\n"+idQuiz);

        nbrAttente(idQuiz);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myQuiz);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myQuiz:
                        Intent act3 = new Intent(getApplicationContext(), MyQuiz.class);
                        act3.putExtra("nom", extraName);
                        act3.putExtra("email", extraEmail);
                        act3.putExtra("prenom", extraFirstName);
                        act3.putExtra("id", extraId);
                        startActivity(act3);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myProfile:
                        Intent act2 = new Intent(getApplicationContext(), ProfileProf.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                }
                return false;
            }

        });


        DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(EditQuiz.this);
                alertDialogBuilder.setTitle(R.string.deletequiz);
                alertDialogBuilder.setIcon(R.mipmap.redcross);
                alertDialogBuilder.setMessage(R.string.wantdeletequiz);
                alertDialogBuilder.setCancelable(false);
                alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteQuiz(idQuiz,extraName,extraFirstName,extraEmail,extraId);
                    }
                });
                alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();


            }
        });

        LaunchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(EditQuiz.this);
                alertDialogBuilder.setTitle(R.string.launchquiz);
                alertDialogBuilder.setIcon(R.mipmap.launch);
                alertDialogBuilder.setMessage(R.string.wantlaunchquiz);
                alertDialogBuilder.setCancelable(false);
                alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        launchQuiz(idQuiz,extraName,extraFirstName,extraEmail,extraId);
                        addReal(idQuiz,extraName,extraEmail,extraFirstName,extraId);
                        addInfo(idQuiz,extraId);

                    }
                });
                alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

    }

    private void addInfo(final String idQuiz,final String idp) {
        Date now = new Date();

        DateFormat dateformatter = DateFormat.getDateInstance(DateFormat.SHORT);
        final String formattedDate = dateformatter.format(now);

        DateFormat timeformatter = DateFormat.getTimeInstance(DateFormat.SHORT);
        final String formattedTime = timeformatter.format(now);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"infoQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                params.put("idp",idp);
                params.put("datequiz",formattedDate);
                params.put("heure",formattedTime);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void addReal(final String idQuiz, final String extraName, final String extraEmail, final String extraFirstName, final String extraId) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"addReal.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbr=object.getString("nbr").trim();
                            //Toast.makeText(EditQuiz.this, nbr, Toast.LENGTH_SHORT).show();
                            Intent act = new Intent(getApplicationContext(), ViewQuiz.class);
                            act.putExtra("nom", extraName);
                            act.putExtra("email", extraEmail);
                            act.putExtra("prenom", extraFirstName);
                            act.putExtra("id", extraId);
                            act.putExtra("idQuiz", idQuiz);
                            act.putExtra("nbr", nbr);
                            startActivity(act);
                            finish();

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(EditQuiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void launchQuiz(final String idQuiz , final String extraName, final String extraFirstName, final String extraEmail, final String extraId) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"launchQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void deleteQuiz(final String idQuiz, final String extraName, final String extraFirstName, final String extraEmail, final String extraId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"deleteQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent act3 = new Intent(getApplicationContext(), MyQuiz.class);
                act3.putExtra("nom", extraName);
                act3.putExtra("email", extraEmail);
                act3.putExtra("prenom", extraFirstName);
                act3.putExtra("id", extraId);
                startActivity(act3);
                finish();

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void nbrAttente(final String idQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"nbrAttente.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbrattente=object.getString("enattente").trim();
                            nbrco.setText(nbrattente+" "+getString(R.string.studentsconnected));

                            nbrAttenteboucle(idQuiz);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(EditQuiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


    private void nbrAttenteboucle(final String idQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"nbrAttente.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbrattente=object.getString("enattente").trim();
                            nbrco.setText(nbrattente+" "+getString(R.string.studentsconnected));

                            nbrAttenteboucle(idQuiz);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(EditQuiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                for(int j=0;j<2000000000;j++);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void onBackPressed(){

    }
}
