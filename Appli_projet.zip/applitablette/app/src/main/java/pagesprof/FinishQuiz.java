package pagesprof;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class FinishQuiz extends AppCompatActivity {

    private Button save;
    private TextInputLayout til_quizName;
    private EditText ed_quizName;
    private TextView code;
    private String url = "http://81.49.43.234/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish_quiz);

        Intent intent = getIntent();
        final String extraName=intent.getStringExtra("nom");
        final String extraFirstName=intent.getStringExtra("prenom");
        final String extraEmail=intent.getStringExtra("email");
        final String extraId=intent.getStringExtra("id");
        final String extraIdQuiz=intent.getStringExtra("idQuiz");

        final String idProf= extraId.toString().trim();
        final String idQuiz= extraIdQuiz.toString().trim();


        code = findViewById(R.id.code);
        til_quizName = findViewById(R.id.til_quizName);
        ed_quizName = findViewById(R.id.ed_quizName);
        save = findViewById(R.id.save);

        code.setText(idQuiz);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String quizName;
                if(ed_quizName.length() == 0){
                    til_quizName.setError(getString(R.string.enterName));
                }else{
                    quizName= ed_quizName.getText().toString().trim();
                    til_quizName.setErrorEnabled(false);
                    finishQuiz(quizName,idProf,idQuiz);

                    Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                    act.putExtra("nom",extraName);
                    act.putExtra("email",extraEmail);
                    act.putExtra("prenom",extraFirstName);
                    act.putExtra("id",extraId);
                    startActivity(act);
                    finish();
                }
            }
        });



    }

    private void finishQuiz(final String quizName, final String idp, final String idQuiz) {
        Date now = new Date();

        DateFormat dateformatter = DateFormat.getDateInstance(DateFormat.SHORT);
        final String formattedDate = dateformatter.format(now);

        DateFormat timeformatter = DateFormat.getTimeInstance(DateFormat.SHORT);
        final String formattedTime = timeformatter.format(now);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url +"finishQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(FinishQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idProf",idp);
                params.put("quizName",quizName);
                params.put("idQuiz",idQuiz);
                params.put("datecreation",formattedDate);
                params.put("heure",formattedTime);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void onBackPressed(){

    }
}
