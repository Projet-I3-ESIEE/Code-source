package pagesprof;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class InfoResult extends AppCompatActivity {

    private TextView note,moyennetxt,best,worst,t1,t2,t3,t4;
    private Button studentmark,menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_result);
        note = findViewById(R.id.note);
        moyennetxt = findViewById(R.id.moyennetxt);
        best = findViewById(R.id.infosnotes);
        worst = findViewById(R.id.worst);
        t1 = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        t3 = findViewById(R.id.t3);
        t4 = findViewById(R.id.t4);
        studentmark = findViewById(R.id.studentsmark);
        menu = findViewById(R.id.gomenu);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");
        final String extraidQuiz = intent.getStringExtra("idQuiz");
        final String nomQuiz = intent.getStringExtra("nomQuiz");
        final String nbr = intent.getStringExtra("nbr");

        note.setText(nomQuiz);


        noteMoyenne(extraidQuiz,nbr);

        entre0et5(extraidQuiz,nbr);
        entre5et10(extraidQuiz,nbr);
        entre10et15(extraidQuiz,nbr);
        entre15et20(extraidQuiz,nbr);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), QuizResults.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                startActivity(act);
                finish();
            }
        });

        studentmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), NotesEleves.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                act.putExtra("idQuiz", extraidQuiz);
                act.putExtra("nbr", nbr);
                startActivity(act);
            }
        });

    }

    private void noteMoyenne(final String idQuiz,final String nbr) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/getNotes.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);

                            String moyenne = object.getString("noteSur20").trim();
                            String noteMin = object.getString("noteMin").trim();
                            String noteMax = object.getString("noteMax").trim();

                            moyennetxt.setText(moyenne + " / 20");
                            best.setText(getString(R.string.bestmark)+noteMax+" / 20");
                            worst.setText(getString(R.string.worstmark)+noteMin+" / 20");
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(InfoResult.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(InfoResult.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", idQuiz);
                params.put("nbr", nbr);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void entre0et5(final String idQuiz, final String nbr) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/entre0et5.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbr = object.getString("nbr").trim();

                            t1.setText(getString(R.string.lessthan5)+nbr);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(InfoResult.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(InfoResult.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", idQuiz);
                params.put("nbr", nbr);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void entre5et10(final String idQuiz, final String nbr) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/entre5et10.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbr = object.getString("nbr").trim();

                            t2.setText(getString(R.string.between5and10)+nbr);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(InfoResult.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(InfoResult.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", idQuiz);
                params.put("nbr", nbr);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void entre10et15(final String idQuiz, final String nbr) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/entre10et15.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbr = object.getString("nbr").trim();

                            t3.setText(getString(R.string.between10and15)+nbr);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(InfoResult.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(InfoResult.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", idQuiz);
                params.put("nbr", nbr);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void entre15et20(final String idQuiz, final String nbr) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/entre15et20.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbr = object.getString("nbr").trim();

                            t4.setText(getString(R.string.morethan15)+nbr);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(InfoResult.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(InfoResult.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", idQuiz);
                params.put("nbr", nbr);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void onBackPressed(){

    }
}
