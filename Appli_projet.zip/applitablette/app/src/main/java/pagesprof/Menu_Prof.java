package pagesprof;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Menu_Prof extends AppCompatActivity {


    private TextView create,seeresult,claim;
    String url = "http://92.148.72.130/menu_prof.php";


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__prof);

        create = (TextView) findViewById(R.id.create);
        seeresult = (TextView) findViewById(R.id.seeresult);
        claim = (TextView) findViewById(R.id.claim);

        Random r = new Random();
        final int valeur = 100000 + r.nextInt(999999 - 100000);
        final String idprovisoire = Integer.toString(valeur);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");

        BottomNavigationView bottomNavigationView = findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.home);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.myQuiz:
                        Intent act = new Intent(getApplicationContext(), MyQuiz.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                    case R.id.home:
                        break;
                    case R.id.myProfile:
                        Intent act2 = new Intent(getApplicationContext(), ProfileProf.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                }
                return false;
            }

        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createtable(extraName,extraEmail,extraFirstName,extraId);
            }
        });

        seeresult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), QuizResults.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                startActivity(act);
                finish();

            }
        });

        claim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), MyClaims.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                startActivity(act);
                finish();

            }
        });

    }

    private void createtable(final String extraName, final String extraEmail, final String extraFirstName, final String extraId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/createTableQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);

                            String idQuiz=object.getString("idQuiz").trim();
                            Intent act = new Intent(getApplicationContext(), CreateQuiz.class);
                            act.putExtra("nom", extraName);
                            act.putExtra("email", extraEmail);
                            act.putExtra("prenom", extraFirstName);
                            act.putExtra("id", extraId);
                            act.putExtra("idQuiz",idQuiz);
                            startActivity(act);
                            finish();

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Menu_Prof.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Menu_Prof.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void onBackPressed() {

    }


}
