package pagesprof;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pageseleves.ActivitiesEleve;

public class NotesEleves extends AppCompatActivity {

    public LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes_eleves);

        layout = findViewById(R.id.myQuizLayout);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");
        final String extraidQuiz = intent.getStringExtra("idQuiz");
        final String nbr = intent.getStringExtra("nbr");

        List namesList = new ArrayList();

        getnbrEleve(extraidQuiz, namesList,nbr);

    }

    private void getnbrEleve(final String idQuiz, final List nameList,final String nbr) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/getNbrNotesEleves.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String nbrQuiz = object.getString("nbr").trim();
                            String numMin = object.getString("num").trim();
                            String cpt = "0";

                            if (!nbrQuiz.equals("0")) {
                                listEleves(idQuiz, numMin, nbrQuiz, cpt, nameList,nbr);
                                //Toast.makeText(NotesEleves.this, numMin, Toast.LENGTH_SHORT).show();
                            }

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(NotesEleves.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(NotesEleves.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", idQuiz);
                params.put("nbrr", nbr);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void listEleves(final String idQuiz, final String num, final String nbrQuiz, final String cpt, final List nameList,final String nbrreal) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/viewStudentMark.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String note = object.getString("mark").trim();
                            String num = object.getString("num").trim();
                            String nome = object.getString("nome").trim();
                            String prenome = object.getString("prenome").trim();

                            int nbr = Integer.parseInt(num);
                            nbr++;
                            num = Integer.toString(nbr);

                            int compteur = Integer.parseInt(cpt);
                            compteur++;
                            final String compte = Integer.toString(compteur);

                            nameList.add(nome + " " + prenome + " : " + note + " / 20");


                            if (compte.equals(nbrQuiz)) {
                                //loading.setVisibility(View.INVISIBLE);

                                Collections.sort(nameList);
//
                                for (int j = 0; j < compteur; j++) {
                                    Button button = new Button(NotesEleves.this);
                                    button.setText(nameList.get(j).toString());
                                    button.setId(j);
                                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                    params.gravity = Gravity.CENTER_HORIZONTAL;
                                    params.setMargins(5, 0, 5, 0);
                                    button.setTextColor(getResources().getColor(R.color.white));
                                    button.setBackgroundColor(Color.TRANSPARENT);
                                    button.setLines(1);
                                    button.setTextSize(16);


                                    layout.addView(button, params);

//                                    final Button button1;
//                                    button1 = findViewById(j);
//                                    button1.setOnClickListener(new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View v) {
//                                            String txt = button1.getText().toString().trim();
//                                            Toast.makeText(NotesEleves.this, txt, Toast.LENGTH_SHORT).show();
//                                            int tailleNomQuiz = nomQuiz.length() + 2;
//                                            String idQuiz = txt.substring(tailleNomQuiz);
//                                            Intent act = new Intent(getApplicationContext(), EditQuiz.class);
//                                            act.putExtra("nom", extraName);
//                                            act.putExtra("email", extraEmail);
//                                            act.putExtra("prenom", extraFirstName);
//                                            act.putExtra("id", extraId);
//                                            act.putExtra("idQuiz", idQuiz);
//                                            startActivity(act);
//                                            finish();
//
//                                        }
//                                    });

                                }
                            } else {
                                listEleves(idQuiz, num, nbrQuiz, compte, nameList,nbrreal);
                            }

//


                        }
                    } else {
                        int nbr = Integer.parseInt(num);
                        nbr++;
                        String nmbr = Integer.toString(nbr);
                        listEleves(idQuiz, nmbr, nbrQuiz, cpt, nameList,nbrreal);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(NotesEleves.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(NotesEleves.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", idQuiz);
                params.put("num", num);
                params.put("nbrreal", nbrreal);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}
