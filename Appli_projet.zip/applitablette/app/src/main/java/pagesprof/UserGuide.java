package pagesprof;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.appli_projet.FirstPage;
import com.example.myapplication.R;

public class UserGuide extends AppCompatActivity {

    private Button retour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_guide);

        retour = findViewById(R.id.btnexit);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");

        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                act.putExtra("nom",extraName);
                act.putExtra("email",extraEmail);
                act.putExtra("prenom",extraFirstName);
                act.putExtra("id",extraId);
                startActivity(act);
                finish();
            }
        });
    }

    public void onBackPressed() {

    }
}
