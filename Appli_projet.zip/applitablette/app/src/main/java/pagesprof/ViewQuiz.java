package pagesprof;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class ViewQuiz extends AppCompatActivity {

    private TextView nbrQuestion, Question;
    private Button truetext, falsetext, textqcm1, textqcm2, textqcm3, textqcm4;
    private ProgressBar progress,loading;
    private CheckBox check1, check2, check3, check4, truechecked, falsechecked;
    private TextView til_answer;
    private ImageView ardoise,tableau;
    int counter = 0;
    String score = "0";
    String cpt = "1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_quiz);

        nbrQuestion = findViewById(R.id.numberQuestion);
        progress = findViewById(R.id.progress);
        Question = findViewById(R.id.question);
        check1 = findViewById(R.id.check1);
        check2 = findViewById(R.id.check2);
        check3 = findViewById(R.id.check3);
        check4 = findViewById(R.id.check4);
        textqcm1 = findViewById(R.id.textqcm1);
        textqcm2 = findViewById(R.id.textqcm2);
        textqcm3 = findViewById(R.id.textqcm3);
        textqcm4 = findViewById(R.id.textqcm4);
        til_answer = findViewById(R.id.til_answer);
        truetext = findViewById(R.id.truetext);
        falsetext = findViewById(R.id.falsetext);
        truechecked = findViewById(R.id.truechecked);
        falsechecked = findViewById(R.id.falsechecked);
        ardoise = findViewById(R.id.ardoise);
        loading= findViewById(R.id.loadbar);
        tableau = findViewById(R.id.tableau);

        check1.setClickable(false);
        check2.setClickable(false);
        check3.setClickable(false);
        check4.setClickable(false);
        truechecked.setClickable(false);
        falsechecked.setClickable(false);
        textqcm1.setClickable(false);
        textqcm2.setClickable(false);
        textqcm3.setClickable(false);
        textqcm4.setClickable(false);
        til_answer.setClickable(false);
        truetext.setClickable(false);
        falsetext.setClickable(false);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");
        final String extraidQuiz = intent.getStringExtra("idQuiz");
        final String nbr = intent.getStringExtra("nbr");

        nbrQuestion.setText("Question 1");

        nbrQuestion(cpt, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,nbr);

    }

    private void prog(final String nbrQuest, final String cpt, final String type,final String trueFalse, final String answer, final String qcmvrai1, final String qcmvrai2, final String qcmvrai3, final String qcmvrai4, final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName,final String nbr) {

        final Timer t = new Timer();
        TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                counter++;
                progress.setProgress(counter);
                if (counter == 100) {

                    t.cancel();
                    int points = Integer.parseInt(score);
                    final String note;
                    int compteur = Integer.parseInt(cpt);
                    compteur++;
                    final String compte = Integer.toString(compteur);
                    int qcmrep1, qcmrep2, qcmrep3, qcmrep4;


                    if (nbrQuest.equals(cpt)) {
                        textqcm1.setVisibility(View.INVISIBLE);
                        textqcm2.setVisibility(View.INVISIBLE);
                        textqcm3.setVisibility(View.INVISIBLE);
                        textqcm4.setVisibility(View.INVISIBLE);
                        check1.setVisibility(View.INVISIBLE);
                        check2.setVisibility(View.INVISIBLE);
                        check3.setVisibility(View.INVISIBLE);
                        check4.setVisibility(View.INVISIBLE);
                        til_answer.setVisibility(View.INVISIBLE);
                        truetext.setVisibility(View.INVISIBLE);
                        falsetext.setVisibility(View.INVISIBLE);
                        ardoise.setVisibility(View.INVISIBLE);
                        tableau.setVisibility(View.INVISIBLE);
                        nbrQuestion.setVisibility(View.INVISIBLE);
                        progress.setVisibility(View.INVISIBLE);
                        Question.setText("Waiting for the students to finish the quiz");

                        checkattente(extraidQuiz,extraName,extraEmail,extraFirstName,extraId,nbr);

                    } else {

                        Quiz(nbrQuest, compte, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,nbr);
                    }

                }
            }
        };
        t.schedule(tt, 0, 310);//310
    }

    private void checkattente(final String idQuiz,final String extraName, final String extraEmail, final String extraFirstName, final String extraId,final String nbr) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/nbrAttente.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nbrattente=object.getString("enattente").trim();

                            if(nbrattente.equals("0")){
                                loading.setVisibility(View.INVISIBLE);
                                Intent act = new Intent(getApplicationContext(), PageFinQuiz.class);
                                act.putExtra("nom", extraName);
                                act.putExtra("email", extraEmail);
                                act.putExtra("prenom", extraFirstName);
                                act.putExtra("id", extraId);
                                act.putExtra("idQuiz", idQuiz);
                                act.putExtra("cpt", cpt);
                                act.putExtra("nbr", nbr);
                                startActivity(act);
                                finish();
                            }
                            else{
                                loading.setVisibility(View.VISIBLE);
                                for(int j=0;j<1000000000;j++);
                                checkattente(idQuiz,extraName,extraEmail,extraFirstName,extraId,nbr);
                            }

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(ViewQuiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ViewQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void Quiz(final String nbrQuest, final String cpt, final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName,final String nbr) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/getQuestions.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);

                            String id = object.getString("id").trim();
                            String type = object.getString("type").trim();
                            String questions = object.getString("question").trim();
                            String qcm1 = object.getString("qcm1").trim();
                            String qcm2 = object.getString("qcm2").trim();
                            String qcm3 = object.getString("qcm3").trim();
                            String qcm4 = object.getString("qcm4").trim();
                            String qcmvrai1 = object.getString("qcmvrai1").trim();
                            String qcmvrai2 = object.getString("qcmvrai2").trim();
                            String qcmvrai3 = object.getString("qcmvrai3").trim();
                            String qcmvrai4 = object.getString("qcmvrai4").trim();
                            String TrueFalse = object.getString("TrueFalse").trim();
                            String answer = object.getString("answer").trim();

                            nbrQuestion.setText(id + "/" + nbrQuest);
                            Question.setText(questions);

                            textqcm1.setBackground(null);
                            textqcm2.setBackground(null);
                            textqcm3.setBackground(null);
                            textqcm4.setBackground(null);
                            check1.setChecked(false);
                            check2.setChecked(false);
                            check3.setChecked(false);
                            check4.setChecked(false);
                            truetext.setBackground(null);
                            falsetext.setBackground(null);
                            truechecked.setChecked(false);
                            falsechecked.setChecked(false);
                            til_answer.setText("");


                            if (type.equals("1")) {
                                textqcm1.setText(qcm1);
                                textqcm2.setText(qcm2);
                                textqcm1.setVisibility(View.VISIBLE);
                                textqcm2.setVisibility(View.VISIBLE);
                                check1.setVisibility(View.INVISIBLE);
                                check2.setVisibility(View.INVISIBLE);
                                til_answer.setVisibility(View.INVISIBLE);
                                truetext.setVisibility(View.INVISIBLE);
                                falsetext.setVisibility(View.INVISIBLE);
                                ardoise.setVisibility(View.INVISIBLE);

                                if(qcmvrai1.equals("yes")){
                                    textqcm1.setBackgroundColor(Color.parseColor("#42D336"));
                                }
                                else{
                                    textqcm1.setBackgroundColor(Color.parseColor("#CB2722"));
                                }
                                if(qcmvrai2.equals("yes")){
                                    textqcm2.setBackgroundColor(Color.parseColor("#42D336"));
                                }
                                else{
                                    textqcm2.setBackgroundColor(Color.parseColor("#CB2722"));
                                }

                                if (!qcm3.equals("")) {
                                    textqcm3.setText(qcm3);
                                    textqcm3.setVisibility(View.VISIBLE);
                                    check3.setVisibility(View.INVISIBLE);
                                    if(qcmvrai3.equals("yes")){
                                        textqcm3.setBackgroundColor(Color.parseColor("#42D336"));
                                    }
                                    else{
                                        textqcm3.setBackgroundColor(Color.parseColor("#CB2722"));
                                    }

                                } else {
                                    textqcm3.setVisibility(View.INVISIBLE);
                                    check3.setVisibility(View.INVISIBLE);
                                }

                                if (!qcm4.equals("")) {
                                    textqcm4.setText(qcm4);
                                    textqcm4.setVisibility(View.VISIBLE);
                                    check4.setVisibility(View.INVISIBLE);

                                    if(qcmvrai4.equals("yes")){
                                        textqcm4.setBackgroundColor(Color.parseColor("#42D336"));
                                    }
                                    else{
                                        textqcm4.setBackgroundColor(Color.parseColor("#CB2722"));
                                    }

                                } else {
                                    textqcm4.setVisibility(View.INVISIBLE);
                                    check4.setVisibility(View.INVISIBLE);
                                }

                            } else if (type.equals("2")) {
                                textqcm1.setVisibility(View.INVISIBLE);
                                textqcm2.setVisibility(View.INVISIBLE);
                                textqcm3.setVisibility(View.INVISIBLE);
                                textqcm4.setVisibility(View.INVISIBLE);
                                check1.setVisibility(View.INVISIBLE);
                                check2.setVisibility(View.INVISIBLE);
                                check3.setVisibility(View.INVISIBLE);
                                check4.setVisibility(View.INVISIBLE);
                                til_answer.setVisibility(View.INVISIBLE);
                                truetext.setVisibility(View.VISIBLE);
                                falsetext.setVisibility(View.VISIBLE);
                                ardoise.setVisibility(View.INVISIBLE);

                                if(TrueFalse.equals("True")){
                                    truetext.setVisibility(View.VISIBLE);
                                    falsetext.setVisibility(View.INVISIBLE);
                                }
                                else{
                                    truetext.setVisibility(View.INVISIBLE);
                                    falsetext.setVisibility(View.VISIBLE);
                                }


                            } else {
                                textqcm1.setVisibility(View.INVISIBLE);
                                textqcm2.setVisibility(View.INVISIBLE);
                                textqcm3.setVisibility(View.INVISIBLE);
                                textqcm4.setVisibility(View.INVISIBLE);
                                check1.setVisibility(View.INVISIBLE);
                                check2.setVisibility(View.INVISIBLE);
                                check3.setVisibility(View.INVISIBLE);
                                check4.setVisibility(View.INVISIBLE);
                                til_answer.setVisibility(View.VISIBLE);
                                truetext.setVisibility(View.INVISIBLE);
                                falsetext.setVisibility(View.INVISIBLE);
                                ardoise.setVisibility(View.VISIBLE);

                                til_answer.setText(answer);

                            }
                            counter = 0;
                            prog(nbrQuest, cpt, type, TrueFalse, answer, qcmvrai1, qcmvrai2, qcmvrai3, qcmvrai4, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,nbr);

                        }

                    } else {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(ViewQuiz.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ViewQuiz.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", extraidQuiz);
                params.put("cpt", cpt);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void nbrQuestion(final String cpt, final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName,final String nbr) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://92.148.72.130/getnbrQuest.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String nbrQuest = object.getString("nbr").trim();
                            Quiz(nbrQuest, cpt, extraEmail, extraFirstName, extraId, extraidQuiz, extraName,nbr);

                        }
                    } else {
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(ViewQuiz.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
                }


            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ViewQuiz.this, "Error " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idQuiz", extraidQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }



    public void onBackPressed() {

    }
}
