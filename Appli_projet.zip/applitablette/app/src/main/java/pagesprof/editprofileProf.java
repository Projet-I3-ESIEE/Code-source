package pagesprof;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputLayout;

import java.util.HashMap;
import java.util.Map;

import pageseleves.ActivitiesEleve;
import pageseleves.Menu_eleve;
import pageseleves.ProfileEleve;
import pageseleves.editprofileEleve;

public class editprofileProf extends AppCompatActivity {

    private Button changemail, changepasswd, btn;
    private EditText edmail, edpasswd, edpasswd2;
    private ImageView ardoisemail, ardoisepasswd, editmail, editpasswd;
    private TextInputLayout tilmail, tilpasswd, tilpasswd2;
    private TextView txtmail, txtpasswd;
    private String url = "http://81.49.43.234/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editprofile_prof);

        changemail = findViewById(R.id.changemail);
        changepasswd = findViewById(R.id.changepasswd);
        btn = findViewById(R.id.btn);

        ardoisemail = findViewById(R.id.ardoisemail);
        ardoisepasswd = findViewById(R.id.ardoisepasswd);
        txtmail = findViewById(R.id.entermailtxt);
        txtpasswd = findViewById(R.id.enterpasswordtxt);

        tilmail = findViewById(R.id.til_email);
        tilpasswd = findViewById(R.id.til_passwd);
        tilpasswd2 = findViewById(R.id.til_passwd2);
        edmail = findViewById(R.id.ed_email);
        edpasswd = findViewById(R.id.ed_passwd);
        edpasswd2 = findViewById(R.id.ed_passwd2);

        editmail = findViewById(R.id.editmail);
        editpasswd = findViewById(R.id.editpasswd);


        final Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");


        changemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editmail.setVisibility(View.VISIBLE);
                changemail.setVisibility(View.INVISIBLE);
                txtmail.setVisibility(View.VISIBLE);
                tilmail.setVisibility(View.VISIBLE);

                editpasswd.setVisibility(View.INVISIBLE);
                changepasswd.setVisibility(View.VISIBLE);
                txtpasswd.setVisibility(View.INVISIBLE);
                tilpasswd.setVisibility(View.INVISIBLE);
                tilpasswd2.setVisibility(View.INVISIBLE);

            }
        });

        changepasswd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editpasswd.setVisibility(View.VISIBLE);
                changepasswd.setVisibility(View.INVISIBLE);
                txtpasswd.setVisibility(View.VISIBLE);
                tilpasswd.setVisibility(View.VISIBLE);
                tilpasswd2.setVisibility(View.VISIBLE);

                editmail.setVisibility(View.INVISIBLE);
                changemail.setVisibility(View.VISIBLE);
                txtmail.setVisibility(View.INVISIBLE);
                tilmail.setVisibility(View.INVISIBLE);
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtmail.getVisibility() == View.VISIBLE) {
                    if (!isEmailValid(edmail.getText().toString())) {
                        Toast.makeText(editprofileProf.this, (getString(R.string.InvalidEmail)), Toast.LENGTH_SHORT).show();
                    } else {
                        String mail = edmail.getText().toString().trim();
                        editemail(extraId,mail,extraName,extraEmail,extraFirstName,extraId);
                    }

                } else if(txtpasswd.getVisibility() == View.VISIBLE){
                    if (edpasswd.length() == 0 || edpasswd2.length() == 0) {
                        Toast.makeText(editprofileProf.this, (getString(R.string.EnterPassword)), Toast.LENGTH_SHORT).show();
                    } else if (!(edpasswd.getText().toString().trim()).equals(edpasswd2.getText().toString().trim())) {
                        Toast.makeText(editprofileProf.this, (getString(R.string.NotSamePassword)), Toast.LENGTH_SHORT).show();
                    }
                    else if(edpasswd.length() <8){
                        Toast.makeText(editprofileProf.this, R.string.passwordtoshort, Toast.LENGTH_SHORT).show();
                    }
                    else {
                        String mdp = edpasswd.getText().toString().trim();
                        editpassword(extraId,mdp,extraName,extraEmail,extraFirstName,extraId);
                    }
                }
                else{
                    Toast.makeText(editprofileProf.this, R.string.editsmthg, Toast.LENGTH_SHORT).show();
                }
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myProfile);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.myQuiz:
                        Intent act = new Intent(getApplicationContext(), MyQuiz.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                    case R.id.myProfile:
                        Intent act3 = new Intent(getApplicationContext(), ProfileProf.class);
                        act3.putExtra("nom", extraName);
                        act3.putExtra("email", extraEmail);
                        act3.putExtra("prenom", extraFirstName);
                        act3.putExtra("id", extraId);
                        startActivity(act3);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                    case R.id.home:
                        Intent act2 = new Intent(getApplicationContext(), Menu_Prof.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                }
                return false;

            }
        });

    }

    private void editemail(final String id, final String mail,final String extraName, final String extraEmail, final String extraFirstName, final String extraId) {

        StringRequest request = new StringRequest(Request.Method.POST, url +"editemailprof.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent act = new Intent(getApplicationContext(), ProfileProf.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", mail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                startActivity(act);
                finish();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(editprofileProf.this, error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }

        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("idp", id);
                params.put("email", mail);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void editpassword(final String id, final String password,final String extraName, final String extraEmail, final String extraFirstName, final String extraId) {

        StringRequest request = new StringRequest(Request.Method.POST, url +"editpasswordprof.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent act = new Intent(getApplicationContext(), ProfileProf.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                startActivity(act);
                finish();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(editprofileProf.this, error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }

        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("idp", id);
                params.put("password", password);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    boolean isEmailValid(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public void onBackPressed() {

    }
}